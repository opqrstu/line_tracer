﻿/*
 * blue_ctrl.h
 *
 * Created: 2020-05-09 오후 8:09:08
 *  Author: woo
 */ 


#ifndef BLUE_CTRL_H_
#define BLUE_CTRL_H_


void write_blue(const char *format, ...);


#endif /* BLUE_CTRL_H_ */