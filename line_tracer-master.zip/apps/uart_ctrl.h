﻿/*
 * uart_ctrl.h
 *
 * Created: 2020-04-26 오후 4:55:31
 *  Author: woo
 */ 


#ifndef UART_CTRL_H_
#define UART_CTRL_H_


void write_uart(const char *format, ...);


#endif /* UART_CTRL_H_ */