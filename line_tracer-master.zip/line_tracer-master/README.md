gcc -o aaa main.c drivers/list.c; ./aaa
