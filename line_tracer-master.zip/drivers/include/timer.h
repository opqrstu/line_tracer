﻿#ifndef TIMER_H_
#define TIMER_H_

#define GET_SEC 0


#endif /* TIMER_H_ */